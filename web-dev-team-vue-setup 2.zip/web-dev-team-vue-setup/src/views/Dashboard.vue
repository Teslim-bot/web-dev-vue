<template>
  <div>
    <p>A beautiful dashboard page</p>
  </div>
</template>

<script>
export default {
  name: "Dashboard"
};
</script>

<style scoped></style>

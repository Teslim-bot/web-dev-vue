<template>
  <div class="app-layout">
    <slot />
  </div>
</template>

<script>
export default {
  name: "AppLayout"
};
</script>

<style scoped></style>

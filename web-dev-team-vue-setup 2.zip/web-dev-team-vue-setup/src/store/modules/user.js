import AuthServices from "../../services/AuthServices";
import LoaderUtils from "../../utils/BaseUtils/LoaderUtils";
import StoreUtils from "../../utils/BaseUtils/StoreUtils";
import form from "bootstrap-vue/esm/mixins/form";
const authService = new AuthServices();

export const namespaced = true;

export const state = {
  userInfo: {}
};

export const getters = {
  getUserInfo: state => {
    return state.userInfo;
  }
};

export const mutations = {
  SET_USER_INFO(state, payload) {
    state.userInfo = payload;
  }
};

export const actions = {};
